"""FastAPI backend. Run: uvicorn app:app --reload  (from backend/)"""
import json, os, secrets, time
from datetime import date
from pathlib import Path as FsPath
from typing import Literal, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Path, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

import base64, binascii
import booking_reader, demo_inbox, engine, insurance, wallet

BASE = FsPath(__file__).parent
DATA = BASE / "data"
if not (DATA / "customers.json").exists():
    import data_gen; data_gen.main()

CUSTOMERS = {c["id"]: c for c in json.loads((DATA / "customers.json").read_text())}
TX = json.loads((DATA / "transactions.json").read_text())
for _c in CUSTOMERS.values():  # demo balances (synthetic)
    _c.setdefault("eur_balance_cents", 250_000 if _c["id"].startswith("demo_") else 100_000)
    _c.setdefault("issued_policies", [])
TRIP_STATE: dict[str, dict] = {}   # trip_id -> owner, overrides, insurance answers/status, pocket status
SESSIONS: dict[str, tuple[str, float]] = {}  # token -> (customer_id, expiry)
DEMO_USERS = {"lotte": "demo_lotte", "wout": "demo_wout", "emma": "demo_emma"}
DEMO_PASSWORD = os.getenv("DEMO_PASSWORD")  # set in .env, never hardcoded

app = FastAPI(title="Booked -> Ready (KBC Trip Mode prototype)")


# ---------- Auth: user always comes from the token, never from the URL ----------
class Login(BaseModel):
    username: str = Field(max_length=32)
    password: str = Field(max_length=64)


@app.post("/api/login")
def login(body: Login):
    cid = DEMO_USERS.get(body.username.lower())
    if not DEMO_PASSWORD or not cid or not secrets.compare_digest(body.password, DEMO_PASSWORD):
        raise HTTPException(401, "Invalid credentials")
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = (cid, time.time() + 3600)
    return {"token": token}


def current_customer(authorization: str = Header(default="")) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    sess = SESSIONS.get(token)
    if not sess or sess[1] < time.time():
        raise HTTPException(401, "Not logged in")
    return CUSTOMERS[sess[0]]


def my_trips(c: dict) -> list[engine.Trip]:
    trips = engine.detect_trips([t for t in TX if t["customer_id"] == c["id"]])
    out = []
    for t in trips:
        st = TRIP_STATE.setdefault(t.id, {"owner": c["id"], "status": "new", "overrides": {},
                                          "answers": {}, "modules": None, "policy": None, "pocket": None})
        out.append(t.model_copy(update=st["overrides"]))
    return out


def get_my_trip(c: dict, trip_id: str) -> tuple[engine.Trip, dict, list[engine.Trip]]:
    trips = my_trips(c)
    for t in trips:
        if t.id == trip_id and TRIP_STATE[t.id]["owner"] == c["id"]:  # ownership check (no IDOR)
            return t, TRIP_STATE[t.id], trips
    raise HTTPException(404, "Trip not found")


def insurance_view(c: dict, trip: engine.Trip, st: dict, all_trips: list) -> dict:
    rec = insurance.recommend(c, trip, trips_last_year=len(all_trips) - 1)
    if st["policy"]:
        return {"status": "issued", "policy": st["policy"]}
    if rec["status"] == "covered":
        return rec
    selected = st["modules"] if st["modules"] is not None else [m["code"] for m in rec["modules"] if m["recommended"]]
    for m in rec["modules"]:
        m["selected"] = m["code"] in selected
    fields = insurance.build_form(c, trip, st["answers"])
    rec.update(form=fields, summary=insurance.form_summary(fields),
               total_premium_eur=round(sum(m["premium_eur"] for m in rec["modules"] if m["selected"]), 2))
    return rec


# ---------- Profile + Trip Mode ----------
@app.get("/api/me")
def me(c: dict = Depends(current_customer)):
    return {"name": c["name"], "trip_mode": c["trip_mode"], "policies": c["policies"],
            "currency_pockets": c["currency_pockets"], "eur_balance": c["eur_balance_cents"] / 100,
            "active_policies": sum(1 for p in c["issued_policies"] if p["status"] == "active")}


class TripMode(BaseModel):
    enabled: bool


@app.put("/api/me/trip-mode")
def set_trip_mode(body: TripMode, c: dict = Depends(current_customer)):
    c["trip_mode"] = body.enabled
    detected = []
    if body.enabled:
        for eid, status in list(c.get("inbox", {}).items()):
            if status == "waiting":
                d = process_email(c, demo_inbox.BY_ID[eid])
                if d and d not in detected:
                    detected.append(d)
    return {"trip_mode": c["trip_mode"], "detected": detected}


# ---------- Trips ----------
@app.get("/api/me/trips")
def list_trips(c: dict = Depends(current_customer)):
    if not c["trip_mode"]:
        return {"trip_mode": False, "trips": []}   # opt-out respected: no detection shown
    trips = my_trips(c)
    res = []
    for t in trips:
        st = TRIP_STATE[t.id]
        if st["status"] == "dismissed":
            continue
        res.append({"trip": t.model_dump(), "status": st["status"],
                    "insurance": insurance_view(c, t, st, trips),
                    "pocket": st["pocket"] or engine.currency_pocket(t),
                    "pocket_open": bool(st["pocket"]),
                    "card_warning": engine.card_warning(c["card_issued"], t)})
    return {"trip_mode": True, "trips": res}


class TripEdit(BaseModel):
    start: Optional[date] = None
    end: Optional[date] = None
    travellers: Optional[int] = Field(default=None, ge=1, le=10)


@app.patch("/api/me/trips/{trip_id}")
def edit_trip(trip_id: str, body: TripEdit, c: dict = Depends(current_customer)):
    trip, st, _ = get_my_trip(c, trip_id)
    if st["policy"]:
        raise HTTPException(409, "Policy already issued")
    start = (body.start or date.fromisoformat(trip.start)).isoformat()
    end = (body.end or date.fromisoformat(trip.end)).isoformat()
    if end <= start:
        raise HTTPException(400, "Return must be after departure")
    if (date.fromisoformat(end) - date.fromisoformat(start)).days > 120:
        raise HTTPException(400, "Single-trip insurance covers up to 120 days")
    st["overrides"].update(start=start, end=end, dates_estimated=False)  # saving = user confirmed dates
    if body.travellers:
        st["overrides"]["travellers"] = body.travellers
    return {"ok": True}


@app.post("/api/me/trips/{trip_id}/dismiss")
def dismiss(trip_id: str, c: dict = Depends(current_customer)):
    _, st, _ = get_my_trip(c, trip_id)
    st["status"] = "dismissed"
    return {"ok": True}


# ---------- Travel insurance ----------
class InsuranceAnswers(BaseModel):
    modules: Optional[list[Literal["assistance", "cancellation", "luggage"]]] = Field(default=None, max_length=3)
    phone: Optional[str] = Field(default=None, pattern=r"^\+?[0-9 ]{8,18}$")
    co_travellers: Optional[list[str]] = Field(default=None, max_length=9)


@app.put("/api/me/trips/{trip_id}/insurance")
def update_insurance(trip_id: str, body: InsuranceAnswers, c: dict = Depends(current_customer)):
    _, st, _ = get_my_trip(c, trip_id)
    if st["policy"]:
        raise HTTPException(409, "Policy already issued")
    if body.modules is not None:
        st["modules"] = sorted(set(body.modules))
    if body.phone:
        st["answers"]["phone"] = body.phone.strip()
    if body.co_travellers is not None:
        names = [n.strip()[:60] for n in body.co_travellers]
        st["answers"]["co_travellers"] = names
    return {"ok": True}


class Sign(BaseModel):
    accept_terms: bool


@app.post("/api/me/trips/{trip_id}/insurance/sign")
def sign_insurance(trip_id: str, body: Sign, c: dict = Depends(current_customer)):
    trip, st, trips = get_my_trip(c, trip_id)
    view = insurance_view(c, trip, st, trips)  # recomputed server-side: client prices are never trusted
    if view["status"] != "suggested":
        raise HTTPException(409, "Nothing to sign")
    if not body.accept_terms:
        raise HTTPException(400, "Please accept the terms")
    s = view["summary"]
    if s["missing"] or s["to_check"]:
        raise HTTPException(400, "Complete or confirm: " + ", ".join(s["missing"] + s["to_check"]))
    chosen = [m for m in view["modules"] if m["selected"]]
    if not chosen:
        raise HTTPException(400, "Select at least one cover")
    premium_cents = round(view["total_premium_eur"] * 100)
    if premium_cents > c["eur_balance_cents"]:
        raise HTTPException(400, "Not enough money on your current account for the premium")
    c["eur_balance_cents"] -= premium_cents
    st["policy"] = {"number": f"TRV-{secrets.randbelow(900000) + 100000}", "status": "active",
                    "trip_id": trip.id, "destination": f"{trip.city}, {trip.country}",
                    "product": view["product"], "zone": view["zone"],
                    "cover_codes": [m["code"] for m in chosen],
                    "covers": [m["title"] for m in chosen], "premium_eur": view["total_premium_eur"],
                    "from": trip.start, "to": trip.end, "travellers": trip.travellers}
    c["issued_policies"].append(st["policy"])
    return {"ok": True, "policy": st["policy"]}


# ---------- Booking confirmation upload (AI reads it) ----------
def apply_booking(c: dict, st: dict, info: booking_reader.BookingInfo) -> list[str]:
    """Write what was read from a booking document into the trip + insurance answers."""
    src = "Booking confirmation (read by AI)" if info.method == "ai" else "Booking confirmation"
    found = []
    if info.departure and info.return_date:
        st["overrides"].update(start=info.departure.isoformat(), end=info.return_date.isoformat(), dates_estimated=False)
        st["answers"]["dates_source"] = src
        found.append("travel dates")
    if info.city and info.country:
        st["overrides"].update(city=info.city, country=info.country, currency=engine.CURRENCY.get(info.country))
        found.append("destination")
    if info.passengers:
        me = c["name"].lower()
        known = st["answers"].get("co_travellers", []) if st["answers"].get("names_source") else []
        others = list(dict.fromkeys(known + [n for n in info.passengers if n.lower() != me]))  # merge flight + hotel
        st["overrides"]["travellers"] = len(others) + 1
        st["answers"].update(co_travellers=others, travellers_source=src, names_source=src)
        found.append(f"{len(info.passengers)} traveller name(s)")
    if info.booking_reference:
        st["answers"]["booking_reference"] = info.booking_reference
        found.append("booking reference")
    return found


class BookingUpload(BaseModel):
    mime: str = Field(max_length=40)
    data_b64: str = Field(max_length=7_000_000)  # ~5 MB file


@app.post("/api/me/trips/{trip_id}/booking")
def upload_booking(trip_id: str, body: BookingUpload, c: dict = Depends(current_customer)):
    trip, st, _ = get_my_trip(c, trip_id)
    if st["policy"]:
        raise HTTPException(409, "Policy already issued")
    try:
        data = base64.b64decode(body.data_b64, validate=True)
        info = booking_reader.extract(data, body.mime)
    except booking_reader.BookingError as e:
        raise HTTPException(400, str(e))
    except binascii.Error:
        raise HTTPException(400, "Invalid file")
    except Exception:
        raise HTTPException(400, "Could not read this document")

    found = apply_booking(c, st, info)
    if not found:
        raise HTTPException(422, "No trip details found in this document")
    return {"ok": True, "method": info.method, "found": found}


# ---------- Currency pocket ----------
@app.post("/api/me/trips/{trip_id}/pocket")
def open_pocket(trip_id: str, c: dict = Depends(current_customer)):
    trip, st, _ = get_my_trip(c, trip_id)
    pocket = engine.currency_pocket(trip)
    if not pocket:
        raise HTTPException(400, "No foreign currency needed for this trip")
    wallet.open_pocket(c, pocket["currency"], trip_id, pocket["auto_convert_back_on"],
                       {"amount": pocket["suggested_amount"], "eur": pocket["cost_eur"]})
    st["pocket"] = pocket
    return {"ok": True, "pocket": pocket}


# ---------- Manage: currency pockets (multi-currency account) ----------
CUR = Path(pattern="^[A-Z]{3}$")


def wallet_call(fn, *args):
    try:
        return fn(*args)
    except wallet.WalletError as e:
        raise HTTPException(400, str(e))


@app.get("/api/me/wallet")
def get_wallet(c: dict = Depends(current_customer)):
    return wallet.wallet_view(c)


class NewPocket(BaseModel):
    currency: str = Field(pattern="^[A-Z]{3}$")


@app.post("/api/me/pockets")
def new_pocket(body: NewPocket, c: dict = Depends(current_customer)):
    wallet_call(wallet.open_pocket, c, body.currency)
    return wallet.wallet_view(c)


class Amount(BaseModel):
    amount: Optional[float] = Field(default=None, gt=0, le=10_000_000)


@app.get("/api/me/pockets/{cur}/quote")
def quote(cur: str = CUR, amount_eur: float = Query(gt=0, le=10_000), c: dict = Depends(current_customer)):
    return wallet_call(wallet.quote, c, cur, round(amount_eur * 100))


@app.post("/api/me/pockets/{cur}/top-up")
def top_up(body: Amount, cur: str = CUR, c: dict = Depends(current_customer)):
    if body.amount is None or body.amount > 10_000:
        raise HTTPException(400, "Amount must be between €1 and €10,000")
    return wallet_call(wallet.top_up, c, cur, round(body.amount * 100))


@app.post("/api/me/pockets/{cur}/convert-back")
def convert_back(body: Amount, cur: str = CUR, c: dict = Depends(current_customer)):
    return wallet_call(wallet.convert_back, c, cur, body.amount)


class PocketSettings(BaseModel):
    auto_convert_back: bool


@app.put("/api/me/pockets/{cur}")
def pocket_settings(body: PocketSettings, cur: str = CUR, c: dict = Depends(current_customer)):
    p = wallet_call(wallet._pocket, c, cur)
    p["auto_convert_back"] = body.auto_convert_back
    return {"ok": True}


@app.delete("/api/me/pockets/{cur}")
def close_pocket(cur: str = CUR, c: dict = Depends(current_customer)):
    res = wallet_call(wallet.close_pocket, c, cur)
    for st in TRIP_STATE.values():
        if st["owner"] == c["id"] and st["pocket"] and st["pocket"]["currency"] == cur:
            st["pocket"] = None
    return res


# ---------- Manage: travel insurance policies ----------
def my_policy(c: dict, number: str) -> dict:
    for p in c["issued_policies"]:
        if p["number"] == number:   # only searches this customer's own policies (no IDOR)
            return p
    raise HTTPException(404, "Policy not found")


@app.get("/api/me/policies")
def list_policies(c: dict = Depends(current_customer)):
    return {"annual_travel": c["policies"].get("annual_travel", False),
            "credit_card_travel_pack": c["policies"].get("credit_card_travel_pack", False),
            "assistance_phone": "+32 16 24 24 24",
            "policies": [{**p, "can_change": p["status"] == "active" and date.fromisoformat(p["from"]) > date.today(),
                          "addable": [{"code": code, "premium_eur": price}
                                      for code, price in insurance.premiums(_policy_trip(c, p)).items()
                                      if code not in p["cover_codes"]] if p["status"] == "active" else []}
                         for p in reversed(c["issued_policies"])]}


def _policy_trip(c: dict, p: dict) -> engine.Trip:
    return engine.Trip(id=p["trip_id"], city=None, country=p["destination"].split(", ")[-1], currency=None,
                       start=p["from"], end=p["to"], dates_estimated=False, travellers=p["travellers"],
                       total_cost_eur=next((t.total_cost_eur for t in my_trips(c) if t.id == p["trip_id"]), 0),
                       source_transactions=[])


class AddCover(BaseModel):
    code: Literal["assistance", "cancellation", "luggage"]


@app.post("/api/me/policies/{number}/covers")
def add_cover(body: AddCover, number: str = Path(max_length=20), c: dict = Depends(current_customer)):
    p = my_policy(c, number)
    if p["status"] != "active" or date.fromisoformat(p["from"]) <= date.today():
        raise HTTPException(409, "Covers can only be changed before departure")
    if body.code in p["cover_codes"]:
        raise HTTPException(409, "Already covered")
    price = insurance.premiums(_policy_trip(c, p))[body.code]   # server-side price
    if round(price * 100) > c["eur_balance_cents"]:
        raise HTTPException(400, "Not enough money on your current account")
    c["eur_balance_cents"] -= round(price * 100)
    p["cover_codes"].append(body.code)
    p["covers"].append(insurance.TITLES[body.code])
    p["premium_eur"] = round(p["premium_eur"] + price, 2)
    return {"ok": True, "charged_eur": price}


@app.post("/api/me/policies/{number}/cancel")
def cancel_policy(number: str = Path(max_length=20), c: dict = Depends(current_customer)):
    p = my_policy(c, number)
    if p["status"] != "active" or date.fromisoformat(p["from"]) <= date.today():
        raise HTTPException(409, "Only policies for trips that haven't started can be cancelled")
    p["status"] = "cancelled"
    c["eur_balance_cents"] += round(p["premium_eur"] * 100)   # demo rule: full refund before departure
    st = TRIP_STATE.get(p["trip_id"])
    if st and st["owner"] == c["id"]:
        st["policy"] = None   # trip shows the suggestion again
    return {"ok": True, "refunded_eur": p["premium_eur"]}


# ---------- Demo helper ----------
def process_email(c: dict, email: dict) -> Optional[dict]:
    """Trip Mode is on: find the trip this email's payment belongs to and read the email."""
    key = f"{email['tx']['date']} {email['tx']['merchant']}"
    for t in my_trips(c):
        if any(s.startswith(key) for s in t.source_transactions):
            st = TRIP_STATE[t.id]
            if not st["policy"]:
                text = demo_inbox.personal_body(email, c).encode()
                apply_booking(c, st, booking_reader.extract(text, "text/plain"))
            c["inbox"][email["id"]] = "detected"
            city = st["overrides"].get("city") or t.city
            return {"trip_id": t.id, "city": city}
    c["inbox"][email["id"]] = "ignored"
    return None


@app.get("/api/me/demo/inbox")
def get_inbox(c: dict = Depends(current_customer)):
    return {"trip_mode": c["trip_mode"], "emails": demo_inbox.inbox_view(c)}


@app.post("/api/me/demo/inbox/{email_id}/deliver")
def deliver_email(email_id: str = Path(max_length=40), c: dict = Depends(current_customer)):
    """Demo helper: the booking email arrives and its card payment reaches the account."""
    email = demo_inbox.BY_ID.get(email_id)
    if not email:
        raise HTTPException(404, "Email not found")
    inbox = c.setdefault("inbox", {})
    if email_id in inbox:
        return {"status": inbox[email_id], "already": True, "trip_mode": c["trip_mode"]}
    TX.append({"customer_id": c["id"], **email["tx"]})
    if email["kind"] == "other":
        inbox[email_id] = "ignored"
        return {"status": "ignored", "trip_mode": c["trip_mode"]}
    if not c["trip_mode"]:
        inbox[email_id] = "waiting"   # opt-in: nothing is analysed until Trip Mode is on
        return {"status": "waiting", "trip_mode": False}
    detected = process_email(c, email)
    return {"status": inbox[email_id], "trip_mode": True, "detected": detected}


@app.get("/")
def index():
    return FileResponse(BASE.parent / "frontend" / "index.html")
