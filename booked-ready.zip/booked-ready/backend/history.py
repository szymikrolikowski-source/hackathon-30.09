"""Past trips from card spending abroad, and a personal spending profile.

A past trip = card payments made abroad (country != BE) on consecutive days.
The profile (average spend per day abroad, excluding accommodation, which is
usually prepaid) is the reference for how much currency to exchange next time.
"""
from datetime import date

import engine

CATEGORY = {5812: "Food & drinks", 5814: "Food & drinks", 5411: "Groceries",
            4111: "Transport", 4121: "Transport", 4131: "Transport", 4112: "Transport",
            7011: "Accommodation", 7991: "Activities", 7996: "Activities", 7922: "Activities",
            5311: "Shopping", 5651: "Shopping", 5999: "Shopping", 6011: "Cash withdrawal"}
# Demo price-level index (1.0 ≈ Belgium). Used to scale your habits to a new destination.
PRICE_LEVEL = {"JP": 1.0, "US": 1.15, "GB": 1.1, "CH": 1.3, "CZ": 0.7, "HU": 0.65,
               "ES": 0.9, "IT": 0.95, "PT": 0.85, "FR": 1.0, "NL": 1.0, "DE": 1.0}
COUNTRY_NAME = {"JP": "Japan", "US": "United States", "GB": "United Kingdom", "CZ": "Czechia",
                "HU": "Hungary", "ES": "Spain", "IT": "Italy", "CH": "Switzerland"}
MAX_GAP_DAYS = 3


def past_trips(transactions: list[dict], today: date | None = None) -> list[dict]:
    today = today or date.today()
    abroad = sorted((t for t in transactions if t.get("country", "BE") != "BE"
                     and date.fromisoformat(t["date"]) < today), key=lambda t: t["date"])
    groups: list[list[dict]] = []
    for t in abroad:
        last = groups[-1][-1] if groups else None
        if last and last["country"] == t["country"] and \
                (date.fromisoformat(t["date"]) - date.fromisoformat(last["date"])).days <= MAX_GAP_DAYS:
            groups[-1].append(t)
        else:
            groups.append([t])

    trips = []
    for g in groups:
        start, end = date.fromisoformat(g[0]["date"]), date.fromisoformat(g[-1]["date"])
        days = (end - start).days + 1
        cur = g[0].get("currency", "EUR")
        cats: dict[str, float] = {}
        for t in g:
            cat = CATEGORY.get(t["mcc"], "Other")
            cats[cat] = round(cats.get(cat, 0) + t["amount_eur"], 2)
        total = round(sum(t["amount_eur"] for t in g), 2)
        on_site = round(total - cats.get("Accommodation", 0), 2)
        trips.append({
            "city": g[0].get("city"), "country": g[0]["country"],
            "country_name": COUNTRY_NAME.get(g[0]["country"], g[0]["country"]), "currency": cur,
            "start": start.isoformat(), "end": end.isoformat(), "days": days,
            "total_eur": total, "total_local": round(sum(t.get("amount_local", t["amount_eur"]) for t in g), 2),
            "per_day_eur": round(on_site / days, 2),
            "categories": dict(sorted(cats.items(), key=lambda kv: -kv[1])),
            "transactions": [{"date": t["date"], "merchant": t["merchant"],
                              "category": CATEGORY.get(t["mcc"], "Other"),
                              "amount_local": t.get("amount_local", t["amount_eur"]), "amount_eur": t["amount_eur"]}
                             for t in g],
        })
    return list(reversed(trips))  # newest first


def spending_profile(trips: list[dict]) -> dict | None:
    """Average on-site spend per day (excl. accommodation), normalised to a price level of 1.0."""
    if not trips:
        return None
    days = sum(t["days"] for t in trips)
    on_site = sum(t["per_day_eur"] * t["days"] for t in trips)
    normalised = sum(t["per_day_eur"] * t["days"] / PRICE_LEVEL.get(t["country"], 1.0) for t in trips)
    return {"trips": len(trips), "days": days,
            "avg_per_day_eur": round(on_site / days, 2),
            "base_per_day_eur": round(normalised / days, 2)}


def daily_for(profile: dict, country: str) -> float:
    return round(profile["base_per_day_eur"] * PRICE_LEVEL.get(country, 1.0), 2)
