"""Travel insurance feature: recommend a policy and pre-fill its application form.

Decisions (which modules, prices) are plain code. The customer only reviews,
fills what is missing and signs. Premiums are placeholder demo tariffs.
"""
from datetime import date
from engine import EUROPE, Trip

ANNUAL_PRICE_PER_PERSON = 95.0
TITLES = {"assistance": "Travel assistance", "cancellation": "Cancellation", "luggage": "Luggage"}  # demo tariff for a yearly (continuous) policy


def _days(trip: Trip) -> int:
    return max(1, (date.fromisoformat(trip.end) - date.fromisoformat(trip.start)).days)


def premiums(trip: Trip) -> dict:
    d, n = _days(trip), trip.travellers
    worldwide = trip.country not in EUROPE
    return {
        "assistance": round((1.2 if worldwide else 0.7) * d * n + 8, 2),
        "cancellation": round(max(15, trip.total_cost_eur * 0.045), 2),
        "luggage": round(0.9 * d * n + 5, 2),
    }


def recommend(customer: dict, trip: Trip, trips_last_year: int) -> dict:
    """Which product and which modules to suggest, with a plain-language reason for each."""
    pol = customer["policies"]
    if pol.get("annual_travel"):
        return {"status": "covered",
                "message": "Your yearly travel insurance already covers this trip. Nothing to do."}

    worldwide = trip.country not in EUROPE
    prices = premiums(trip)
    modules = [
        {"code": "assistance", "title": "Travel assistance",
         "desc": "Medical costs, hospital, repatriation",
         "recommended": worldwide or not pol.get("hospitalisation"),
         "reason": ("Medical costs outside Europe can reach tens of thousands of euros."
                    if worldwide else "You have no hospitalisation insurance for trips abroad.")
         if (worldwide or not pol.get("hospitalisation")) else "Your hospitalisation insurance covers Europe."},
        {"code": "cancellation", "title": "Cancellation",
         "desc": f"Refund of your €{trip.total_cost_eur:.0f} if you must cancel",
         "recommended": trip.total_cost_eur >= 300 and not pol.get("credit_card_travel_pack"),
         "reason": ("Already covered by your credit card travel pack."
                    if pol.get("credit_card_travel_pack")
                    else f"You already paid €{trip.total_cost_eur:.0f}. Best taken out right after booking.")},
        {"code": "luggage", "title": "Luggage", "desc": "Stolen, lost or damaged luggage",
         "recommended": False, "reason": "Optional."},
    ]
    for m in modules:
        m["premium_eur"] = prices[m["code"]]

    annual_hint = None
    if trips_last_year >= 2:
        annual_hint = (f"You travel often ({trips_last_year + 1} trips this year). A yearly policy "
                       f"(≈ €{ANNUAL_PRICE_PER_PERSON * trip.travellers:.0f}) may be cheaper.")
    return {"status": "suggested",
            "product": "Single-trip travel insurance",
            "zone": "Worldwide" if worldwide else "Europe",
            "modules": modules, "annual_hint": annual_hint}


def build_form(customer: dict, trip: Trip, answers: dict) -> list[dict]:
    """Every field of the application, with its value, its source and whether the user must act.

    status: filled = taken from KBC data, check = estimated (user confirms), missing = user must enter.
    """
    p = customer.get("profile", {})
    household = [h["name"] for h in p.get("household", [])]
    co = answers.get("co_travellers") or household[: trip.travellers - 1]

    def f(key, label, value, source, status=None, editable=False):
        st = status or ("filled" if value not in (None, "", []) else "missing")
        return {"key": key, "label": label, "value": value, "source": source,
                "status": st, "editable": editable or st == "missing"}

    fields = [
        f("name", "Policyholder", customer["name"], "KBC profile"),
        f("birth_date", "Date of birth", p.get("birth_date"), "KBC profile"),
        f("address", "Address", p.get("address"), "KBC profile"),
        f("email", "Email", p.get("email"), "KBC profile"),
        f("phone", "Phone (for assistance abroad)", answers.get("phone") or p.get("phone"),
          "You" if answers.get("phone") else "KBC profile", editable=True),
        f("destination", "Destination", f"{trip.city}, {trip.country}" if trip.city else None, "Hotel payment"),
        f("zone", "Zone", "Europe" if trip.country in EUROPE else "Worldwide", "From destination"),
        f("departure", "Departure", trip.start, "Estimated from payment date" if trip.dates_estimated else answers.get("dates_source", "Confirmed by you"),
          status="check" if trip.dates_estimated else "filled", editable=True),
        f("return", "Return", trip.end, "Estimated from payment date" if trip.dates_estimated else answers.get("dates_source", "Confirmed by you"),
          status="check" if trip.dates_estimated else "filled", editable=True),
        f("travellers", "Number of travellers", trip.travellers, answers.get("travellers_source", "Estimated from flight price"), editable=True),
    ]
    for i in range(trip.travellers - 1):
        name = co[i] if i < len(co) else None
        fields.append(f(f"co_traveller_{i}", f"Co-traveller {i + 1}", name,
                        "Your household at KBC" if name in household
                        else answers.get("names_source", "You"), editable=True))
    if answers.get("booking_reference"):
        fields.append(f("booking_ref", "Booking reference", answers["booking_reference"], answers.get("dates_source", "Booking")))
    fields.append(f("trip_value", "Insured trip value (cancellation)", trip.total_cost_eur, "Booking payments"))
    fields.append(f("iban", "Pay premium from", p.get("account"), "Your KBC current account"))
    return fields


def form_summary(fields: list[dict]) -> dict:
    return {"total": len(fields),
            "filled": sum(1 for x in fields if x["status"] == "filled"),
            "to_check": [x["label"] for x in fields if x["status"] == "check"],
            "missing": [x["label"] for x in fields if x["status"] == "missing"]}
