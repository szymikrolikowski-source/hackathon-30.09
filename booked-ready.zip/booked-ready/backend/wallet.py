"""Currency pockets (multi-currency account) and policy management.

Money rules (demo, modelled on KBC's public foreign-currency terms):
- Exchanging up to €1,500 per month is free; 1% fee on the part above.
- A pocket holds one foreign currency; paying abroad uses it first.
- On the trip's return date leftovers are converted back to EUR (if enabled).
EUR amounts are kept in integer cents to avoid rounding errors.
"""
from datetime import date

import engine

FREE_MONTHLY_EUR_CENTS = 150_000
FEE_RATE = 0.01
MAX_TX_EUR_CENTS = 1_000_000          # €10,000 per exchange (demo safety limit)
DECIMALS = {"JPY": 0, "HUF": 0}       # others: 2
SUPPORTED = sorted(engine.FX_EUR)


class WalletError(Exception):
    """User-facing error (safe to show)."""


def _round(cur: str, amount: float) -> float:
    return round(amount, DECIMALS.get(cur, 2))


def _check_cur(cur: str) -> None:
    if cur not in engine.FX_EUR:
        raise WalletError("Unsupported currency")


def _fee_cents(c: dict, eur_cents: int) -> int:
    used = c.setdefault("fx_month_cents", 0)
    over = max(0, used + eur_cents - max(used, FREE_MONTHLY_EUR_CENTS))
    return round(over * FEE_RATE)


def quote(c: dict, cur: str, eur_cents: int) -> dict:
    _check_cur(cur)
    if not 100 <= eur_cents <= MAX_TX_EUR_CENTS:
        raise WalletError("Amount must be between €1 and €10,000")
    fee = _fee_cents(c, eur_cents)
    return {"currency": cur, "eur": eur_cents / 100, "fee_eur": fee / 100,
            "receive": _round(cur, eur_cents / 100 * engine.FX_EUR[cur]), "rate": engine.FX_EUR[cur]}


def open_pocket(c: dict, cur: str, trip_id=None, convert_back_on=None, suggested=None) -> dict:
    _check_cur(cur)
    p = c["currency_pockets"].get(cur)
    if p is None:
        p = c["currency_pockets"][cur] = {"balance": 0, "auto_convert_back": True}
    if trip_id:
        p.update(trip=trip_id, auto_convert_back_on=convert_back_on, suggested=suggested)
    return p


def _pocket(c: dict, cur: str) -> dict:
    _check_cur(cur)
    p = c["currency_pockets"].get(cur)
    if p is None:
        raise WalletError("Pocket not found")
    return p


def top_up(c: dict, cur: str, eur_cents: int) -> dict:
    p = _pocket(c, cur)
    q = quote(c, cur, eur_cents)
    total = eur_cents + round(q["fee_eur"] * 100)
    if total > c["eur_balance_cents"]:
        raise WalletError("Not enough money on your current account")
    c["eur_balance_cents"] -= total
    c["fx_month_cents"] += eur_cents
    p["balance"] = _round(cur, p["balance"] + q["receive"])
    return q


def convert_back(c: dict, cur: str, amount: float | None) -> dict:
    p = _pocket(c, cur)
    amount = p["balance"] if amount is None else _round(cur, amount)
    if amount <= 0 or amount > p["balance"]:
        raise WalletError("Amount must be more than 0 and at most your pocket balance")
    eur_cents = int(amount / engine.FX_EUR[cur] * 100)  # rounded down in the bank's favour, as usual
    p["balance"] = _round(cur, p["balance"] - amount)
    c["eur_balance_cents"] += eur_cents
    return {"currency": cur, "converted": amount, "eur": eur_cents / 100}


def close_pocket(c: dict, cur: str) -> dict:
    p = _pocket(c, cur)
    res = convert_back(c, cur, None) if p["balance"] > 0 else {"eur": 0}
    del c["currency_pockets"][cur]
    return res


def run_auto_convert(c: dict, today: date | None = None) -> None:
    """Called on every wallet read: converts leftovers of finished trips back to EUR."""
    today = today or date.today()
    for cur, p in list(c["currency_pockets"].items()):
        due = p.get("auto_convert_back_on")
        if p.get("auto_convert_back") and due and date.fromisoformat(due) < today and p["balance"] > 0:
            convert_back(c, cur, None)
            p["auto_converted_on"] = today.isoformat()


def wallet_view(c: dict) -> dict:
    run_auto_convert(c)
    used = c.get("fx_month_cents", 0)
    return {
        "eur_balance": c["eur_balance_cents"] / 100,
        "free_exchange_left": max(0, FREE_MONTHLY_EUR_CENTS - used) / 100,
        "supported": SUPPORTED,
        "rates": engine.FX_EUR,
        "pockets": [{"currency": cur, **p, "balance_eur": round(p["balance"] / engine.FX_EUR[cur], 2)}
                    for cur, p in sorted(c["currency_pockets"].items())],
    }
