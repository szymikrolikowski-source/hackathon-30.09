"""Synthetic customers + transactions. No real data. Run: python data_gen.py"""
import json, random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)
OUT = Path(__file__).parent / "data"
TODAY = date(2026, 9, 30)

EVERYDAY = [("COLRUYT LEUVEN", 5411, 20, 90), ("DELHAIZE", 5411, 10, 70),
            ("SPOTIFY AB", 4899, 11.99, 11.99), ("TOTAL ENERGIES", 5541, 40, 80),
            ("NMBS/SNCB", 4112, 5, 30), ("BOL.COM", 5399, 15, 120)]
FIRST = ["Lotte", "Wout", "Emma", "Arne", "Lien", "Jonas", "Marie", "Tom", "Noor", "Pieter"]
LAST = ["Peeters", "Janssens", "Maes", "Jacobs", "Mertens", "Willems", "Claes", "Goossens"]


def everyday_tx(cid, n=40):
    tx = []
    for _ in range(n):
        m, mcc, lo, hi = random.choice(EVERYDAY)
        d = TODAY - timedelta(days=random.randint(1, 120))
        tx.append({"customer_id": cid, "date": d.isoformat(), "merchant": m,
                   "mcc": mcc, "amount_eur": round(random.uniform(lo, hi), 2)})
    return tx


def make_customer(i):
    cid = f"c{i:04d}"
    return {
        "id": cid,
        "name": f"{random.choice(FIRST)} {random.choice(LAST)}",
        "age": random.randint(20, 60),
        "home_country": "BE",
        "card_issued": (TODAY - timedelta(days=random.randint(100, 2500))).isoformat(),
        "policies": {
            "annual_travel": random.random() < 0.15,
            "credit_card_travel_pack": random.random() < 0.2,
            "hospitalisation": random.random() < 0.6,
        },
        "trip_mode": True,
        "currency_pockets": {},
        "profile": {"birth_date": f"{2026 - random.randint(20, 60)}-0{random.randint(1, 9)}-1{random.randint(0, 9)}",
                    "address": f"Voorbeeldstraat {random.randint(1, 200)}, 3000 Leuven",
                    "email": f"{cid}@example.com", "phone": "+32 470 00 00 00",
                    "household": [], "account": f"BE•• •••• •••• {random.randint(1000, 9999)}"},
    }


def main():
    OUT.mkdir(exist_ok=True)
    customers, txs = [], []
    for i in range(1, 1001):
        c = make_customer(i)
        customers.append(c)
        txs += everyday_tx(c["id"])
        if random.random() < 0.12:  # hidden trips in ~12% of customers
            dest = random.choice([("BKG*HTL SHINJUKU GRNVL", 7011, "JP"),
                                  ("BKG*HOTEL MANHATTAN NYC", 7011, "US"),
                                  ("AIRBNB * HMXX LONDON", 7011, "GB"),
                                  ("BKG*HOTEL ROMA TERMINI", 7011, "IT")])
            d = TODAY - timedelta(days=random.randint(1, 20))
            txs.append({"customer_id": c["id"], "date": d.isoformat(),
                        "merchant": random.choice(["BRUSSELS AIRL 082-2231", "RYANAIR DAC FR4521", "KLM 074-8812"]),
                        "mcc": 4511, "amount_eur": round(random.uniform(250, 1400), 2)})
            txs.append({"customer_id": c["id"], "date": (d + timedelta(days=1)).isoformat(),
                        "merchant": dest[0], "mcc": dest[1], "amount_eur": round(random.uniform(200, 900), 2)})

    # Three fixed demo users (login accounts) — clean, predictable
    demo = [
        {"id": "demo_lotte", "name": "Lotte Peeters", "age": 24, "home_country": "BE",
         "card_issued": "2021-03-01", "policies": {"annual_travel": False, "credit_card_travel_pack": False, "hospitalisation": True},
         "trip_mode": True, "currency_pockets": {},
         "profile": {"birth_date": "2002-04-17", "address": "Voorbeeldstraat 12, 3000 Leuven",
                     "email": "lotte@example.com", "phone": "+32 470 12 34 56",
                     "household": [{"name": "Jonas Maes", "birth_date": "2001-11-02"}],
                     "account": "BE•• •••• •••• 4417"}},
        {"id": "demo_wout", "name": "Wout Janssens", "age": 31, "home_country": "BE",
         "card_issued": "2025-06-01", "policies": {"annual_travel": True, "credit_card_travel_pack": False, "hospitalisation": True},
         "trip_mode": True, "currency_pockets": {},
         "profile": {"birth_date": "1995-02-08", "address": "Testlaan 4, 2000 Antwerpen",
                     "email": "wout@example.com", "phone": "+32 471 98 76 54", "household": [],
                     "account": "BE•• •••• •••• 2210"}},
        {"id": "demo_emma", "name": "Emma Maes", "age": 27, "home_country": "BE",
         "card_issued": "2024-01-10", "policies": {"annual_travel": False, "credit_card_travel_pack": True, "hospitalisation": False},
         "trip_mode": False, "currency_pockets": {},
         "profile": {"birth_date": "1999-07-23", "address": "Proefplein 9, 1000 Brussel",
                     "email": "emma@example.com", "phone": None, "household": [],
                     "account": "BE•• •••• •••• 8830"}},
    ]
    for c in demo:
        customers.append(c)
        txs += everyday_tx(c["id"], 25)
    # Wout already has a trip booked (NYC); Lotte's booking is injected live in the demo
    txs += [{"customer_id": "demo_wout", "date": "2026-09-25", "merchant": "BRUSSELS AIRL 082-2231", "mcc": 4511, "amount_eur": 980.0},
            {"customer_id": "demo_wout", "date": "2026-09-26", "merchant": "BKG*HOTEL MANHATTAN NYC", "mcc": 7011, "amount_eur": 720.0}]

    (OUT / "customers.json").write_text(json.dumps(customers, indent=1))
    (OUT / "transactions.json").write_text(json.dumps(txs, indent=1))
    print(f"{len(customers)} customers, {len(txs)} transactions written to {OUT}")


if __name__ == "__main__":
    main()
