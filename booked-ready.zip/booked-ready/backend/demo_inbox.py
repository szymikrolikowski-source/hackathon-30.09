"""Demo inbox: fictional booking emails the presenter 'delivers' to the logged-in user.

Delivering an email simulates two real-world signals at once:
  1. the card payment for that booking reaches KBC (a transaction), and
  2. the confirmation email is available to Kate (only with Trip Mode on, i.e. opt-in).
All companies, references and people are fictional.
"""

EMAILS = [
    {"id": "flight_tokyo", "kind": "flight", "from": "SkyDemo Airways", "received": "28 Sep",
     "subject": "Booking KX7Q2M confirmed: Brussels → Tokyo",
     "tx": {"date": "2026-09-28", "merchant": "BRUSSELS AIRL 082-2231", "mcc": 4511, "amount_eur": 1120.0},
     "body": ("Thank you for booking with SkyDemo Airways.\n"
              "Booking reference: KX7Q2M\nPassenger 1: {name}\nPassenger 2: {partner}\n"
              "Outbound: Brussels (BRU) -> Tokyo Haneda (HND), 12/10/2026, 13:40\n"
              "Return: Tokyo Haneda (HND) -> Brussels (BRU), 24/10/2026, 11:05\n"
              "Total paid: EUR 1,120.00")},
    {"id": "hotel_tokyo", "kind": "hotel", "from": "Hotel Shinjuku Demo", "received": "29 Sep",
     "subject": "Your stay in Tokyo is confirmed",
     "tx": {"date": "2026-09-29", "merchant": "BKG*HTL SHINJUKU GRNVL 0823", "mcc": 7011, "amount_eur": 410.0},
     "body": ("Reservation confirmed at Hotel Shinjuku Demo, Tokyo.\n"
              "Guest: {name}\nCheck-in: 12/10/2026\nCheck-out: 24/10/2026\n"
              "Room: double, 2 adults\nTotal paid: EUR 410.00")},
    {"id": "receipt_music", "kind": "other", "from": "Music streaming", "received": "27 Sep",
     "subject": "Your monthly receipt",
     "tx": {"date": "2026-09-27", "merchant": "SPOTIFY AB", "mcc": 4899, "amount_eur": 11.99},
     "body": "Thanks for your payment of EUR 11.99 for your monthly subscription."},
    {"id": "flight_nyc", "kind": "flight", "from": "Atlantic Demo Air", "received": "10 Sep",
     "subject": "E-ticket NY4Z8P: Brussels → New York",
     "tx": {"date": "2026-09-10", "merchant": "KLM 074-8812", "mcc": 4511, "amount_eur": 760.0},
     "body": ("Your e-ticket is ready.\nBooking reference: NY4Z8P\nPassenger 1: {name}\n"
              "Outbound: Brussels (BRU) -> New York (JFK), 3 Dec 2026\n"
              "Return: New York (JFK) -> Brussels (BRU), 10 Dec 2026\nTotal paid: EUR 760.00")},
    {"id": "hotel_nyc", "kind": "hotel", "from": "Manhattan Demo Hotel", "received": "11 Sep",
     "subject": "Reservation confirmed: 7 nights in New York",
     "tx": {"date": "2026-09-11", "merchant": "BKG*HOTEL MANHATTAN NYC", "mcc": 7011, "amount_eur": 540.0},
     "body": ("Reservation confirmed at Manhattan Demo Hotel, New York.\nGuest: {name}\n"
              "Check-in: 03/12/2026\nCheck-out: 10/12/2026\nTotal paid: EUR 540.00")},
]
BY_ID = {e["id"]: e for e in EMAILS}


def personal_body(email: dict, customer: dict) -> str:
    household = customer.get("profile", {}).get("household", [])
    partner = household[0]["name"] if household else "Sam Claes"
    return email["body"].format(name=customer["name"], partner=partner)


def inbox_view(customer: dict) -> list[dict]:
    state = customer.setdefault("inbox", {})
    return [{"id": e["id"], "kind": e["kind"], "from": e["from"], "subject": e["subject"],
             "received": e["received"], "body": personal_body(e, customer),
             "status": state.get(e["id"], "new")} for e in EMAILS]
