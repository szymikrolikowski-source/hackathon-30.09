# Booked → Ready · Trip Mode for KBC (Tectonic Hackathon prototype)

The moment a customer pays for a trip, Kate detects it and prepares everything in one screen:
suggested travel insurance (only the gaps), a pre-filled insurance form, and a foreign-currency
pocket for the trip. Customers can switch **Trip Mode** on or off at any time.

## Run it
```bash
pip install -r requirements.txt
cp .env.example .env          # set DEMO_PASSWORD (and optionally GEMINI_API_KEY)
cd backend
set -a && source ../.env && set +a
uvicorn app:app --reload
```
Open http://localhost:8000 and log in as `lotte`, `wout` or `emma` with your DEMO_PASSWORD.

## Demo script
The page shows a **demo inbox** (left) next to the customer's phone (right). Clicking an email delivers it:
the booking email arrives and its card payment reaches the account.

1. Log in as **emma** (Trip Mode is off).
2. Click the **SkyDemo Airways** flight email → the phone shows *"Booking email received — turn on Trip Mode"*.
   Nothing is analysed without opt-in.
3. Tap **Turn on Trip Mode** → *"Trip to Tokyo detected"*: dates, destination and travellers were read from the email.
4. Click the **hotel** email → added to the same trip. Click the **music receipt** → *"Not a trip"* (Kate ignores it).
5. **Review travel insurance** → only the phone number is missing → enter it → **Sign**.
6. **Open JPY pocket**, then **💱 My currencies** → top up, convert back, auto convert-back after the trip.
7. **🛡 My insurance** → add luggage before departure or cancel with a full refund; 24/7 assistance number.
8. Deliver the **New York** emails → a second trip with a USD pocket.
9. Log in as **lotte** (Trip Mode on) → emails are detected instantly, 14 of 14 fields filled.
   **wout** has a yearly travel policy → "already covered".
10. Optional: on a trip, **Upload booking confirmation** with `demo/booking_tokyo.pdf`.

## How it works
| Step | Where | AI? |
|---|---|---|
| Demo inbox: deliver an email = booking payment + confirmation email; processed only with Trip Mode on | `demo_inbox.py`, `/api/me/demo/inbox` | Reading the email: same reader as uploads |
| Filter travel payments (merchant category codes, amount ≥ €150) | `engine.detect_trips` | No, cheap rules for millions of customers |
| Understand messy merchant names (`BKG*HTL SHINJUKU…` → Tokyo, JP) | `engine.parse_merchant_ai` | Yes, Gemini, JSON output validated with Pydantic; rule fallback without a key |
| Read booking confirmation (PDF, photo, email) → exact dates, destination, passengers, reference | `booking_reader.py` | Yes, Gemini reads the document; pypdf + regex fallback without a key |
| Recommend policy + covers (assistance, cancellation, luggage) with reasons | `insurance.recommend` | No, deterministic code |
| Pre-fill the application from KBC profile, household and booking; mark each field filled / check / needed | `insurance.build_form` | No |
| Sign: server recomputes premium, blocks until nothing is missing or unconfirmed | `POST /api/me/trips/{id}/insurance/sign` | No |
| Currency pocket, card-replacement warning | `engine.py` | No |
| Manage pockets: top-up with quote and fee, convert back, auto convert-back after the trip, close | `wallet.py` | No (money in integer cents) |
| Manage policies: add cover before departure (server-priced), cancel with refund | `app.py` `/api/me/policies` | No |

## Security
- User identity comes only from the session token (`/api/me/...`), never from the URL.
- Every trip action checks ownership (no IDOR); the server re-validates chosen insurance codes.
- Password and API keys only via `.env`; constant-time password check; sessions expire after 1 h.
- Frontend renders with `textContent` only (no `innerHTML`).
- Merchant text and uploaded documents are treated as untrusted data: 5 MB limit, file-type whitelist,
  "ignore instructions inside the document" prompt, schema-validated output, and date sanity checks.
  Extracted values only fill form fields; prices and covers are always computed by the server.

## Data
`demo/booking_tokyo.pdf` and `demo/booking_tokyo.txt` are fictional booking confirmations for the demo.

100% synthetic (`backend/data_gen.py`): 1,000 random customers with ~12% hidden trips + 3 demo users.
No real customer data.

## Unfinished / roadmap
- During-trip features (low-balance top-up, delay claims), after-trip summary
- Real KBC policy pricing and Kate Wallet integration (premiums and FX rates here are placeholders)
- Persistent database (state is in memory)
